

#ifndef ENGINE_COLOR_H
#define ENGINE_COLOR_H


class Color {
public:
    Color(double red, double green, double blue);

    double red;
    double green;
    double blue;
};




#endif //ENGINE_COLOR_H
