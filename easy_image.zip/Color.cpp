#include "Color.h"


Color::Color(double red, double green, double blue) : red(red), green(green), blue(blue) {}