#include "Face.h"

Face::Face(const std::vector<int> &pointIndexes) : point_indexes(pointIndexes) {}
