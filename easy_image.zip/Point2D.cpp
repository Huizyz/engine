#include "Point2D.h"

Point2D::Point2D(double x, double y) : x(x), y(y) {}
